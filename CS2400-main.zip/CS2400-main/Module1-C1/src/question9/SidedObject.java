package question9;

public interface SidedObject{
	public int displaySides();
}