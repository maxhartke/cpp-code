package question2;

public class StudentClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student john = new Student(null, null, 0);
		john.setfName("john");
		john.setlName("korah");
		john.setAge(20);
		System.out.println("Name: " + john.getfName());

	}

}
