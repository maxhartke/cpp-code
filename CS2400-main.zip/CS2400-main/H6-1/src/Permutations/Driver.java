package Permutations;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String test_string = new String("batman");
		String[] result = StringPermutator.getStringPermutations(test_string);
	}

}
