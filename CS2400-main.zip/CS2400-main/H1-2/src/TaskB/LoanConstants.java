package TaskB;

public interface LoanConstants {
    int shortTerm = 1;
    int mediumTerm = 3;
    int longTerm = 5;
    int maxLoanAmount = 100000;

}
